INSERT INTO PRODUCT
  VALUES ('P0001', 'iPhone 13 pro', 1350000, '1334X750 Renina HD display, 8-megapixel iSight Camera',
    'Smart Phone', 'Apple', 1000, 'new')